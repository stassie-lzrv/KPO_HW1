package org.example;

public class Player {

    private final int id; // id игрока ( 0 - человек, 1 - компьютер)
    private final char symbol; // симовл игрока на доске
    protected int[][] validMoves = new int[8][8]; //возможные ходы

    protected Player(int id) {
        this.id = id;
        if (id == 0) {
            symbol = '0';
        } else {
            symbol = '*';
        }
    }

    protected int getId() {
        return id;
    }

    protected char getSymbol() {
        return symbol;
    }

}
