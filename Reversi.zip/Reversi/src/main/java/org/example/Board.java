package org.example;

public class Board {

    protected char[][] board = new char[8][8]; // игровая доска

    Board() {
        // заполнение пустой доски
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                board[i][j] = ' ';
            }
        }

        // первые 4 фишки
        board[3][3] = '0';
        board[4][4] = '0';
        board[3][4] = '*';
        board[4][3] = '*';
    }


    protected boolean calculateValidMoves(Player player) {
        int iDelta, jDelta;
        int i, j, x, y;
        boolean haveValidMoves = false;

        char opponent = (player.getId() == 0) ? '*' : '0';

        // очищаем массив
        for (i = 0; i < 8; i++) {
            for (j = 0; j < 8; j++) {
                player.validMoves[i][j] = 0;
            }
        }

        for (i = 0; i < 8; i++)
            for (j = 0; j < 8; j++) {
                if (board[i][j] != ' ') { // если поле не свободно, то переходим к следующему
                    continue;
                }

                // проход по всем соседним клеткам
                for (iDelta = -1; iDelta <= 1; iDelta++) {
                    for (jDelta = -1; jDelta <= 1; jDelta++) {
                        if (i + iDelta < 0 || j + jDelta < 0 || i + iDelta > 7 || j + jDelta > 7 ||
                                (iDelta == 0 && jDelta == 0)) {
                            continue;
                        }

                        if (board[i + iDelta][j + jDelta] == opponent) {
                            x = i + iDelta;
                            y = j + jDelta;


                            for (; ; ) {
                                x += iDelta;
                                y += jDelta;

                                if (x < 0 || y < 0 || x > 7 || y > 7) {
                                    break;
                                }

                                if (board[x][y] == ' ') {
                                    break;
                                }

                                if (board[x][y] == player.getSymbol()) {
                                    player.validMoves[i][j] = 1;   // отмечаем ход возможным
                                    haveValidMoves = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

        return haveValidMoves;
    }


    // ход компьютера в легокм режиме
    protected void computerMove(Player player) {
        Pair<Integer, Integer> bestMove = best_move(player);
        makeMove(bestMove.t, bestMove.u, player);
    }


    // лучший ход компьютера в легком режиме
    private Pair<Integer, Integer> best_move(Player player) {
        int row = 0;
        int col = 0;
        int i, j;
        int bestRow = row;
        int bestCol = col;

        Board boardCopy = new Board();
        double value = 0;
        double maxValue;

        for (row = 0; row < 8; row++) {
            for (col = 0; col < 8; col++) {
                if (player.validMoves[row][col] != 1) {  // если ход невозможен, то переходим к следующей клетке
                    continue;
                }

                // копирование текущей доски
                for (i = 0; i < 8; i++) {
                    for (j = 0; j < 8; j++) {
                        boardCopy.board[i][j] = board[i][j];
                    }
                }

                // подсчет ценности хода
                maxValue = boardCopy.makeMove(row, col, player);

                if (value < maxValue) {
                    value = maxValue;
                    bestRow = row;
                    bestCol = col;
                }
            }
        }
        return new Pair<>(bestRow, bestCol);
    }


    protected double makeMove(int row, int col, Player player) {
        int iDelta, jDelta; // разница
        int x, y;  // индексы для поиска
        char opponent = (player.getId() == 0) ? '*' : '0';
        int n = 0; // число замыкаемых клеток

        board[row][col] = player.getSymbol();

        // проход по всем соседним клетка
        for (iDelta = -1; iDelta <= 1; iDelta++)
            for (jDelta = -1; jDelta <= 1; jDelta++) {
                if (row + iDelta < 0 || col + jDelta < 0 || row + iDelta >= 8 || col + jDelta >= 8 ||
                        (iDelta == 0 && jDelta == 0)) {
                    continue;
                }

                if (board[row + iDelta][col + jDelta] == opponent) {
                    x = row + iDelta;
                    y = col + jDelta;
                    for (; ; ) {
                        x += iDelta;
                        y += jDelta;

                        if (x < 0 || y < 0 || x > 7 || y > 7) {
                            break;
                        }

                        if (board[x][y] == ' ') {
                            break;
                        }

                        // захват фишек оппонента
                        if (board[x][y] == player.getSymbol()) {
                            while (board[x -= iDelta][y -= jDelta] == opponent) {
                                board[x][y] = player.getSymbol();
                                n += (x == 0 || y == 0 || x == 7 || y == 7 ? 2 : 1);
                            }
                            break;
                        }
                    }
                }
            }
        if ((row == 0 && col == 0) || (row == 0 && col == 7) || (row == 7 && col == 0) || (row == 7 && col == 7)) {
            return n + 0.8;
        }
        if (row == 0 || col == 0 || row == 7 || col == 7) {
            return n + 0.4;
        }
        return n;
    }


    // лучший ход в продвинутом режиме
    public void cleverComputerMove(Player player) {
        int row, col;
        double best = 0;
        int bestRow = 0;
        int bestColumn = 0;

        Player computerCopy = new Player(1);
        Player playerCopy = new Player(0);
        Board boardCopy = new Board();
        for (int i = 0; i < 8; i++) {
            System.arraycopy(board[i], 0, boardCopy.board[i], 0, 8);
        }
        boardCopy.calculateValidMoves(computerCopy);
        for (row = 0; row < 8; row++) {
            for (col = 0; col < 8; col++) {
                if (computerCopy.validMoves[row][col] != 1) {   // если ход невозможен, то переходим к следующей клетке
                    continue;
                }

                for (int i = 0; i < 8; i++) {
                    System.arraycopy(board[i], 0, boardCopy.board[i], 0, 8);
                }

                // возможный ход компьютера
                double computerMoveVal = boardCopy.makeMove(row, col, computerCopy);
                boardCopy.calculateValidMoves(playerCopy);
                // лучший ход игрока после хода компьютера
                double bestPlayerVal = boardCopy.countbest_move(playerCopy);
                if (computerMoveVal - bestPlayerVal > best) {
                    best = computerMoveVal - bestPlayerVal;
                    bestRow = row;
                    bestColumn = col;
                }
            }
        }
        makeMove(bestRow, bestColumn, player);
    }

    // тот же bestMove но возвращает ценность лучшего хода))))
    private double countbest_move(Player player) {
        int row, col;
        int i, j;

        Board boardCopy = new Board();
        double value = 0;
        double maxValue = 0;

        for (row = 0; row < 8; row++) {
            for (col = 0; col < 8; col++) {
                if (player.validMoves[row][col] != 1) {   // если ход невозможен, то переходим к следующей клетке
                    continue;
                }

                // копирование текущей доски
                for (i = 0; i < 8; i++) {
                    for (j = 0; j < 8; j++) {
                        boardCopy.board[i][j] = board[i][j];
                    }
                }

                // подсчет ценности хода
                maxValue = boardCopy.makeMove(row, col, player);

                if (value < maxValue) {
                    value = maxValue;
                }
            }
        }
        return maxValue;
    }


    // подсчет очков игрока
    protected int countBoard(Player player) {
        int ans = 0;
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (board[i][j] == player.getSymbol()) {
                    ans += 1;
                }
            }
        }
        return ans;
    }

    protected Board cloneBoard() {
        Board newB = new Board();
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                newB.board[i][j] = this.board[i][j];
            }
        }
        return newB;
    }

}
