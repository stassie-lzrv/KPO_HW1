package org.example;

import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            while (true) {
                Game game = new Game();
                game.startGame();
                System.out.print("\nЕсли хотите сыграть заново нажмите любую клавишу, если хотите выйти введите - ");
                String key = sc.next();
                if (Objects.equals(key, "-")) {
                    System.out.printf("\nНаилучший результат игрока за эту сессию: %s ", game.getBestScore());
                    break;
                }
            }
        } catch (Exception ex) {
            System.out.print("Что-то пошло не так, придется начать игру заново :(\n");
        }
    }
}