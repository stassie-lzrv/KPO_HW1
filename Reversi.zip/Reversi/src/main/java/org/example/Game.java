package org.example;

import java.util.Objects;
import java.util.Scanner;
import java.util.Stack;

public class Game {
    private int gameMode;

    Stack<Board> boardStack = new Stack<>(); // для хода назад
    private static int bestScore = 0; //лучший результат за сессию

    private Board board; // игровая доска
    private final Player firstPlayer; // игрок
    private final Player secondPlayer; // компьютерный игрок

    public Game() {
        board = new Board();
        firstPlayer = new Player(0);
        secondPlayer = new Player(1);
        boardStack.push(board.cloneBoard());
    }

    public int getBestScore() {
        return bestScore;
    }


    // вывод правил
    private static void printRules() {
        System.out.print("""
                РЕВЕРСИ – логическая игра, рассчитанная на двух участников, которые
                играют на доске размером 8x8 фишками разного цвета. Участники начинают игру,
                имея по две фишки, стоящие в центре доски по диагонали друг от друга. В
                процессе игры совершаются ходы, в результате которых число фишек
                увеличивается.
                Цель каждого игрока заключается в том, чтобы к моменту окон-
                чания игры число его фишек преобладало над числом фишек противника.
                В игре приняты следующие нормативные правила:
                • при очередном ходе фишку можно ставить на свободную клетку в любом
                 направлении, но обязательно рядом хотя бы с одной из фишек противника;
                • фишка должна ставиться так, чтобы хотя бы одна из фишек противника
                 оказалась замкнутой своими фишками. При этом замкнутые фишки противника
                 меняют цвет и становятся своими

                             
                """);
    }

    private void chooseGameMode() {
        System.out.print("""
                Выберите режим игры (введите цифру 1, 2, или 3):
                • Легкий <1> - компьютерный игрок делает самый выгодный для себя на текущий момент ход
                • Продвинутый <2> - компьютерный игрок делает самый выгодный для себя ход, учитывая ваши возможные ответные ходы
                • Игрок против игрока <3> - два игрока поочередно делают ходы
                Выбранный режим :
                """);
        Scanner sc = new Scanner(System.in);
        gameMode = sc.nextInt();
        // проверка на корректный ввод
        if (gameMode == 3) {
            System.out.print("Фишки первого игрока - 0\nФишки второго игрока - *\n");
        } else {
            System.out.print("Фишки компьтерного игрока - *\nВаши фишки - 0\n");
        }
    }

    // метод для начала игры
    public void startGame() {
        printRules();
        chooseGameMode();
        if (gameMode == 1) {
            simpleComputerGame();
        } else if (gameMode == 2) {
            cleverComputerGame();
        } else if (gameMode == 3) {
            twoPlayersGame();
        }
    }

    // ввод хода
    private static Pair<Integer, Integer> inputMove(int[][] validMoves) {
        System.out.print("Возможные ходы (на доске отмечены @): ");
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (validMoves[i][j] == 1) {
                    System.out.printf("%s %s, ", i + 1, (char) ('a' + j));
                }
            }

        }
        int x = 0;
        int y = 0;
        System.out.print("Введите свой ход <номер ряда> <буква столбца>: ");
        try {
            Scanner sc = new Scanner(System.in);
            x = sc.nextInt() - 1;
            y = sc.next().charAt(0) - 'a';
        } catch (Exception ex) {
            System.out.print("Некорректно введен ход\n");
        }
        return new Pair<>(x, y);
    }

    private void simpleComputerGame() {
        int n = 0;
        while (true) {
            if (n > 0) {
                boolean flag = goBack();
                if (flag) {
                    printBoard();
                }
            }
            if (board.calculateValidMoves(firstPlayer)) {
                printBoard(firstPlayer.validMoves);
                while (true) {
                    Pair<Integer, Integer> pair = inputMove(firstPlayer.validMoves);
                    int x = pair.t;
                    int y = pair.u;
                    if (x >= 0 && y >= 0 && x < 8 && y < 8 && firstPlayer.validMoves[x][y] == 1) {
                        board.makeMove(x, y, firstPlayer);
                        break;
                    } else {
                        System.out.print("Такой ход невозможен. Попробуйте заново\n");
                    }
                }
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }

            //ход компьтера
            if (board.calculateValidMoves(secondPlayer)) {
                board.computerMove(secondPlayer);
                System.out.print("Компьтерный игрок сделал ход");
                printBoard();
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }
            Board newBoard = board.cloneBoard();
            boardStack.push(newBoard);
            n += 1;
        }
    }

    private void cleverComputerGame() {
        int n = 0;
        while (true) {
            // ход игрока
            if (n > 0) {
                boolean flag = goBack();
                if (flag) {
                    printBoard();
                }
            }
            if (board.calculateValidMoves(firstPlayer)) {
                printBoard(firstPlayer.validMoves);
                while (true) {
                    Pair<Integer, Integer> pair = inputMove(firstPlayer.validMoves);
                    int x = pair.t;
                    int y = pair.u;
                    if (x >= 0 && y >= 0 && x < 8 && y < 8 && firstPlayer.validMoves[x][y] == 1) {
                        board.makeMove(x, y, firstPlayer);
                        break;
                    } else {
                        System.out.print("Такой ход невозможен. Попробуйте заново\n");
                    }
                }
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }

            //ход компьтера
            if (board.calculateValidMoves(secondPlayer)) {
                board.cleverComputerMove(secondPlayer);
                System.out.print("Компьтерный игрок сделал ход");
                printBoard();
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }
            Board newBoard = board.cloneBoard();
            boardStack.push(newBoard);
            n += 1;
        }

    }

    private void twoPlayersGame() {
        int n = 0;
        while (true) {
            // ход игрока
            if (n > 0) {
                boolean flag = goBack();
                if (flag) {
                    printBoard();
                }
            }
            if (board.calculateValidMoves(firstPlayer)) {
                printBoard(firstPlayer.validMoves);
                while (true) {
                    System.out.print("Ход первого игрока\n");
                    Pair<Integer, Integer> pair = inputMove(firstPlayer.validMoves);
                    int x = pair.t;
                    int y = pair.u;
                    if (x >= 0 && y >= 0 && x < 8 && y < 8 && firstPlayer.validMoves[x][y] == 1) {
                        board.makeMove(x, y, firstPlayer);
                        break;
                    } else {
                        System.out.print("Такой ход невозможен. Попробуйте заново\n");
                    }
                }
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }
            //ход второго игрока
            if (board.calculateValidMoves(secondPlayer)) {
                printBoard(secondPlayer.validMoves);
                while (true) {
                    System.out.print("Ход второго игрока\n");
                    Pair<Integer, Integer> pair = inputMove(secondPlayer.validMoves);
                    int x = pair.t;
                    int y = pair.u;
                    if (x >= 0 && y >= 0 && x < 8 && y < 8 && secondPlayer.validMoves[x][y] == 1) {
                        board.makeMove(x, y, secondPlayer);
                        break;
                    } else {
                        System.out.print("Такой ход невозможен. Попробуйте заново\n");
                    }
                }
            } else { //нет шагов
                System.out.print("\nИгра закончена\n");
                printWinner();
                break;
            }

            Board newBoard = board.cloneBoard();
            boardStack.push(newBoard);
            n += 1;
        }

    }


    // вывод доски
    private void printBoard() {
        int i, j;
        char letter = 'a';

        System.out.print("\n ");
        for (j = 0; j < 8; j++) {
            System.out.printf("   %c", letter + j);
        }
        System.out.print("\n");

        for (i = 0; i < 8; i++) {
            System.out.print("  +");
            for (j = 0; j < 8; j++)
                System.out.print("---+");
            System.out.printf("\n%2d|", i + 1);

            for (j = 0; j < 8; j++)
                System.out.printf(" %c |", board.board[i][j]);
            System.out.print("\n");
        }

        System.out.print("  +");
        for (j = 0; j < 8; j++)
            System.out.print("---+");
        System.out.print("\n");
    }


    //вывод доски с возможными ходами
    private void printBoard(int[][] validMoves) {
        int i, j;
        char columnLetter = 'a';

        System.out.print("\n ");
        for (j = 0; j < 8; j++) {
            System.out.printf("   %c", columnLetter + j);
        }
        System.out.print("\n");

        for (i = 0; i < 8; i++) {
            System.out.print("  +");
            for (j = 0; j < 8; j++)
                System.out.print("---+");
            System.out.printf("\n%2d|", i + 1);

            for (j = 0; j < 8; j++)
                System.out.printf(" %c |", (validMoves[i][j] == 1 ? '@' : board.board[i][j]));
            System.out.print("\n");
        }

        System.out.print("  +");
        for (j = 0; j < 8; j++)
            System.out.print("---+");
        System.out.print("\n");
    }

    private boolean goBack() {
        System.out.print("\nЕсли вы хотите отменить прошлый ход введите \"back\", иначе введите любую другую строку : ");
        try {
            Scanner sc = new Scanner(System.in);
            String input = sc.next();
            if (Objects.equals(input, "back")) {
                if (boardStack.isEmpty()) {
                    System.out.print("Невозможно вернуться назад\n");
                    return false;
                }
                if (boardStack.size() == 1) {
                    board = boardStack.peek();
                } else {
                    boardStack.pop();
                    if (boardStack.size() == 1) {
                        board = boardStack.peek().cloneBoard();
                    } else {
                        board = boardStack.pop().cloneBoard();
                    }
                }
                return true;
            }
        } catch (Exception exception) {
            System.out.print("Произошла ошибка");
        }
        return false;
    }

    // вывод информации об выигравшем игроке
    private void printWinner() {
        int firstPlayerCount = board.countBoard(firstPlayer);
        int secondPlayerCount = board.countBoard(secondPlayer);
        if (firstPlayerCount > secondPlayerCount) {
            if (firstPlayerCount > bestScore) {
                bestScore = firstPlayerCount;
            }
            if (gameMode == 3) {
                System.out.printf("Первый игрок выиграл со счётом %s:%s\n", firstPlayerCount, secondPlayerCount);
            } else {
                System.out.printf("Поздравляю! Вы выиграли со счётом %s:%s\n", firstPlayerCount, secondPlayerCount);
            }
        } else {
            if (gameMode == 3) {
                if (secondPlayerCount > bestScore) {
                    bestScore = secondPlayerCount;
                }
                System.out.printf("Второй игрок выиграл со счётом %s:%s\n", secondPlayerCount, firstPlayerCount);
            } else {
                System.out.printf("Не расстраивайтесь! Компьютер выиграл со счётом %s:%s\n", secondPlayerCount, firstPlayerCount);
            }
        }
    }
}
